# Part of Papi Odoo integration. See LICENSE file for full copyright and licensing details.

import logging
import uuid

import requests
from werkzeug.urls import url_join

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

from odoo.addons.payment import utils as payment_utils
from odoo.addons.payment.const import REPORT_REASONS_MAPPING
from odoo.addons.payment_papi import const


_logger = logging.getLogger(__name__)


class PaymentProvider(models.Model):
    _inherit = 'payment.provider'

    code = fields.Selection(
        selection_add=[('papi', "Papi")], ondelete={'papi': 'set default'}
    )
    papi_api_key = fields.Char(
        string="Papi API Key",
        help="The API key of the Papi shop, available in the Papi dashboard under Shops > "
             "Developer. One API key identifies one Papi shop.",
        required_if_provider='papi',
        groups='base.group_system',
    )
    papi_webhook_secret = fields.Char(
        string="Papi Notification Signing Secret",
        help="The secret used to verify the X-Papi-Signature header of notifications. It starts "
             "with 'pwhsec_'.",
        required_if_provider='papi',
        groups='base.group_system',
    )
    papi_shop_name = fields.Char(
        string="Papi Shop",
        help="The name of the Papi shop linked to the API key. Informational only: the shop is "
             "determined by the API key.",
    )
    papi_api_url = fields.Char(
        string="Papi API URL",
        default=const.DEFAULT_API_URL,
        required_if_provider='papi',
    )
    papi_link_validity = fields.Integer(
        string="Payment Link Validity (hours)",
        help="How long the customer can use the Papi payment link before it expires.",
        default=const.LINK_VALIDITY_MIN,
    )

    #=== CONSTRAINT METHODS ===#

    @api.constrains('papi_link_validity')
    def _check_papi_link_validity(self):
        for provider in self.filtered(lambda p: p.code == 'papi'):
            validity = provider.papi_link_validity
            if not const.LINK_VALIDITY_MIN <= validity <= const.LINK_VALIDITY_MAX:
                raise ValidationError(_(
                    "The Papi payment link validity must be between %(min)s and %(max)s hours.",
                    min=const.LINK_VALIDITY_MIN, max=const.LINK_VALIDITY_MAX,
                ))

    @api.constrains('papi_webhook_secret')
    def _check_papi_webhook_secret(self):
        for provider in self.sudo().filtered(lambda p: p.code == 'papi' and p.papi_webhook_secret):
            if not provider.papi_webhook_secret.startswith(const.WEBHOOK_SECRET_PREFIX):
                raise ValidationError(_(
                    "The Papi notification signing secret must start with '%s'.",
                    const.WEBHOOK_SECRET_PREFIX,
                ))

    @api.constrains('papi_api_url')
    def _check_papi_api_url(self):
        for provider in self.filtered(lambda p: p.code == 'papi' and p.papi_api_url):
            if not provider.papi_api_url.startswith('https://'):
                raise ValidationError(_("The Papi API URL must start with https://."))

    #=== BUSINESS METHODS ===#

    @api.model
    def _get_compatible_providers(
        self, company_id, partner_id, amount, *args, is_validation=False, report=None, **kwargs
    ):
        """ Override of `payment` to filter out Papi providers for validation operations, for
        currencies other than MGA and for amounts below the minimum accepted by Papi.

        The currency is checked here as well because the generic filter only relies on the
        `available_currency_ids` field, which the merchant may leave empty.
        """
        providers = super()._get_compatible_providers(
            company_id, partner_id, amount, *args,
            is_validation=is_validation, report=report, **kwargs
        )

        currency = self.env['res.currency'].browse(kwargs.get('currency_id')).exists()
        if currency and currency.name not in const.SUPPORTED_CURRENCIES:
            unfiltered_providers = providers
            providers = providers.filtered(lambda p: p.code != 'papi')
            payment_utils.add_to_report(
                report,
                unfiltered_providers - providers,
                available=False,
                reason=REPORT_REASONS_MAPPING['incompatible_currency'],
            )

        if is_validation:
            unfiltered_providers = providers
            providers = providers.filtered(lambda p: p.code != 'papi')
            payment_utils.add_to_report(
                report,
                unfiltered_providers - providers,
                available=False,
                reason=REPORT_REASONS_MAPPING['validation_not_supported'],
            )
        elif amount and amount < const.MINIMUM_AMOUNT:
            unfiltered_providers = providers
            providers = providers.filtered(lambda p: p.code != 'papi')
            payment_utils.add_to_report(
                report,
                unfiltered_providers - providers,
                available=False,
                reason=_("minimum amount of %s MGA not reached", const.MINIMUM_AMOUNT),
            )

        return providers

    def _get_supported_currencies(self):
        """ Override of `payment` to return the supported currencies. """
        supported_currencies = super()._get_supported_currencies()
        if self.code == 'papi':
            supported_currencies = supported_currencies.filtered(
                lambda c: c.name in const.SUPPORTED_CURRENCIES
            )
        return supported_currencies

    def _get_default_payment_method_codes(self):
        """ Override of `payment` to return the default payment method codes. """
        default_codes = super()._get_default_payment_method_codes()
        if self.code != 'papi':
            return default_codes
        return const.DEFAULT_PAYMENT_METHOD_CODES

    def _papi_send_request(self, endpoint, payload=None, method='POST'):
        """ Send a request to the Papi API and return the raw response.

        The API key is only sent in the `Token` header and is never logged.

        Note: self.ensure_one()

        :param str endpoint: The endpoint to be reached by the request, relative to the API URL.
        :param dict payload: The JSON payload of the request, for POST requests.
        :param str method: The HTTP method of the request.
        :return: The response of the request.
        :rtype: requests.Response
        :raise ValidationError: If the API cannot be reached.
        """
        self.ensure_one()

        url = url_join(self.papi_api_url or const.DEFAULT_API_URL, endpoint)
        headers = {
            'Token': self.sudo().papi_api_key or '',
            'Accept': 'application/json',
        }
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            else:
                response = requests.post(url, json=payload, headers=headers, timeout=10)
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            _logger.exception("Unable to reach Papi endpoint at %s", url)
            raise ValidationError("Papi: " + _("Could not establish the connection to the API."))
        return response

    def _papi_make_request(self, endpoint, payload=None, method='POST'):
        """ Make a request to the Papi API and return the `data` part of the response.

        Only the URL, the HTTP status and the error code/message returned by Papi are logged. The
        error displayed to the customer does not contain any technical detail.

        Note: self.ensure_one()

        :param str endpoint: The endpoint to be reached by the request, relative to the API URL.
        :param dict payload: The JSON payload of the request, for POST requests.
        :param str method: The HTTP method of the request.
        :return: The `data` part of the JSON-formatted content of the response.
        :rtype: dict
        :raise ValidationError: If an HTTP error occurs.
        """
        response = self._papi_send_request(endpoint, payload=payload, method=method)
        content = self._papi_parse_response(response)
        if not response.ok:
            error = content.get('error') or {}
            _logger.error(
                "Papi API request %s %s failed with status %s: %s - %s",
                method, response.url, response.status_code,
                error.get('code'), error.get('message'),
            )
            raise ValidationError("Papi: " + _(
                "The communication with the API failed (HTTP %(status)s, code %(code)s).",
                status=response.status_code, code=error.get('code') or '-',
            ))
        data = content.get('data')
        if not isinstance(data, dict):
            _logger.error(
                "Papi API request %s %s returned an unexpected response.", method, response.url
            )
            raise ValidationError("Papi: " + _("The API returned an unexpected response."))
        return data

    @staticmethod
    def _papi_parse_response(response):
        """ Return the JSON content of the response, or an empty dict if it is not valid JSON. """
        try:
            content = response.json()
        except ValueError:
            return {}
        return content if isinstance(content, dict) else {}

    def action_papi_test_connection(self):
        """ Check that the API key is accepted by Papi and display the result.

        Papi has no dedicated endpoint for this: we read a payment link with a reference that
        cannot exist. A 404 answer means that the API key was accepted; a 401 means it was refused.

        Note: self.ensure_one()

        :return: The notification action.
        :rtype: dict
        """
        self.ensure_one()
        endpoint = f'payment-links/odoo-connection-check-{uuid.uuid4().hex}'
        try:
            response = self._papi_send_request(endpoint, method='GET')
        except ValidationError as error:
            return self._papi_notification(str(error), 'danger')

        if response.status_code in (200, 404):
            message = _("The connection to Papi succeeded: the API key is valid.")
            notification_type = 'success'
        elif response.status_code == 401:
            message = _("Papi refused the API key. Check that it is the key of the right shop.")
            notification_type = 'danger'
        else:
            error = self._papi_parse_response(response).get('error') or {}
            _logger.warning(
                "Papi connection check returned status %s: %s",
                response.status_code, error.get('code'),
            )
            message = _(
                "Papi answered with an unexpected status (HTTP %(status)s, code %(code)s).",
                status=response.status_code, code=error.get('code') or '-',
            )
            notification_type = 'warning'
        return self._papi_notification(message, notification_type)

    @staticmethod
    def _papi_notification(message, notification_type):
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': "Papi",
                'message': message,
                'type': notification_type,
                'sticky': False,
            },
        }
