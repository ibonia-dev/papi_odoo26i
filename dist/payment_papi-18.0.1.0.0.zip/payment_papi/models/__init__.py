# Part of Papi Odoo integration. See LICENSE file for full copyright and licensing details.

from . import payment_provider
from . import payment_transaction
