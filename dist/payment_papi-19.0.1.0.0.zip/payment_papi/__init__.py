# Part of Papi Odoo integration. See LICENSE file for full copyright and licensing details.

from . import controllers
from . import models
from . import wizards

from odoo.addons.payment import setup_provider, reset_payment_provider


def post_init_hook(env):
    setup_provider(env, 'papi')


def uninstall_hook(env):
    reset_payment_provider(env, 'papi')
